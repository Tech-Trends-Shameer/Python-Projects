from flask import Flask, render_template, request, jsonify
from flask_cors import CORS
import requests

app = Flask(__name__)
CORS(app)

def kelvin_to_celsius(kelvin):
    return kelvin - 273.15

@app.route('/')
def index():
    return render_template('dashboard.html')

@app.route('/get_weather', methods=['POST'])
def get_weather():
    try:
        api_key = 'a7d0a9453f9686ba50282182bcc279b1'
        city = request.form['city']
        base_url = f'http://api.openweathermap.org/data/2.5/weather?q={city}&appid={api_key}'
        response = requests.get(base_url)
        data = response.json()
        print(data)  # Print data for debugging
        weather_description = data['weather'][0]['description']
        temperature_kelvin = data['main']['temp']
        temperature_celsius = kelvin_to_celsius(temperature_kelvin)
        humidity = data['main']['humidity']
        return jsonify({'description': weather_description, 'temperature': temperature_celsius, 'humidity': humidity})
    except Exception as e:
        print(str(e))  # Print error for debugging
        return jsonify({'error': str(e)})

if __name__ == "__main__":
    app.run(debug=True)
